package developerpanel.paypay.jp.dto.returnvalues;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import developerpanel.paypay.jp.dto.response.ResultInfoDto;


public class GenericServerResponse {

	@JsonProperty("resultInfo")
	private ResultInfoDto resultInfoDto;
	
	@JsonProperty("data")
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private ServiceReturnValue data;
	
	public GenericServerResponse() {
		
	}
	public GenericServerResponse(ResultInfoDto resultInfoDto,ServiceReturnValue data) {
		this.data = data;
		this.resultInfoDto = resultInfoDto;
	}

	public ResultInfoDto getResultInfoDto() {
		return resultInfoDto;
	}

	public void setResultInfoDto(ResultInfoDto resultInfoDto) {
		this.resultInfoDto = resultInfoDto;
	}

	public ServiceReturnValue getData() {
		return data;
	}

	public void setData(ServiceReturnValue data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "{resultInfo : " + resultInfoDto + ", data : " + data + "}";
	}
	
	

}
