package developerpanel.paypay.jp.dto.request;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmailRequest {
    private Long user_id;
    private String mail_to;
    private String mail_bcc;
    private String mail_from;
    private String mail_from_display_name;
    private String mail_subject;
    private String mail_body;
    private String mail_type;
}
