package developerpanel.paypay.jp.controller;

import developerpanel.paypay.jp.Service.EmailService;
import developerpanel.paypay.jp.Service.JwtUserDetailsService;
import developerpanel.paypay.jp.Service.UserService;
import developerpanel.paypay.jp.config.JwtTokenUtil;
import developerpanel.paypay.jp.dto.request.EmailRequest;
import developerpanel.paypay.jp.dto.request.JwtRequest;
import developerpanel.paypay.jp.dto.request.UserRequest;
import developerpanel.paypay.jp.dto.response.JwtResponse;
import developerpanel.paypay.jp.model.EmailTemplate;
import developerpanel.paypay.jp.model.Users;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
     UserService userService;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtUserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private EmailService emailService;


    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity<?> saveUser(@RequestBody UserRequest user) throws Exception {
        JSONObject jobj=new JSONObject();
        JSONObject resultObj=new JSONObject();
        try {
            Users userResponse= userService.findByEmail(user.getEmail());
            if (userResponse== null)
            {
//                user.setEmail(AES.encrypt(user.getEmail()).toString());
//                user.setPassword(AES.encrypt(user.getPassword()).toString());
                userService.adduser(user);
                resultObj.put("code","SUCCESS");
                resultObj.put("message","Success");
                resultObj.put("codeId","");
                jobj.put("resultInfo",resultObj);
                jobj.put("data","null");
                return ResponseEntity.ok(jobj.toString());
            }
            else
            {
                LOGGER.error("Registered user already exist");
                resultObj.put("code","EMAIL_ID_ALREADY_REGISTERED");
                resultObj.put("message","");
                resultObj.put("codeId","");
                jobj.put("resultInfo",resultObj);
                jobj.put("data","null");
                return ResponseEntity.ok(jobj.toString());
               // return new ResponseEntity<>(jobj.toString(), HttpStatus.NO_CONTENT);
              //  return ResponseEntity.status(HttpStatus.NO_CONTENT).body(jobj.toString());
            }

        } catch (Exception e) {
            LOGGER.error("Registered user already exist");
            resultObj.put("code","EMAIL_ID_ALREADY_REGISTERED");
            resultObj.put("message",e.toString());
            resultObj.put("codeId","");
            jobj.put("resultInfo",resultObj);
            jobj.put("data","null");
            return ResponseEntity.ok(resultObj.toString());
        }
    }

    @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
    public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest jwtRequest) throws Exception {
     //   authenticate(jwtRequest.getEmail(),  jwtRequest.getPassword());
        final UserDetails userDetails = userDetailsService.loadUserByUsername(jwtRequest.getEmail());
        final String token = jwtTokenUtil.generateToken(userDetails);
        EmailTemplate emailTemplate = new EmailTemplate();
        emailTemplate.setBody("http://localhost:8080/hello?"+token);
        emailTemplate.setSendTo("balraj.mys@gmail.com");
        emailTemplate.setSubject("Email Notification");
        emailService.sendTextEmail(emailTemplate);
        LOGGER.info("Email triggered");
        return ResponseEntity.ok(new JwtResponse(token));
       // return null;
    }

    private void authenticate(String email, String password) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
            LOGGER.info("Token generated");
        } catch (DisabledException e) {
            LOGGER.error("User Disabled"+e);
            throw new Exception("USER_DISABLED"+ e);
        } catch (BadCredentialsException e) {
            LOGGER.error("User Invalid Credentials"+e);
            throw new Exception("INVALID_CREDENTIALS"+ e);
        }
    }

    @RequestMapping(value = "/emailnotify", method = RequestMethod.POST)
    public ResponseEntity<?> emailnotify(@RequestBody EmailRequest emailRequest) throws Exception {

        return null;
    }
}
