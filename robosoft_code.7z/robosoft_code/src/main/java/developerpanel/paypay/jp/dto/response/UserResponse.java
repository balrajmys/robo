package developerpanel.paypay.jp.dto.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserResponse {
    private String id;
    private String email;
    private String password;
    private boolean isRegisteredComplete;
}
