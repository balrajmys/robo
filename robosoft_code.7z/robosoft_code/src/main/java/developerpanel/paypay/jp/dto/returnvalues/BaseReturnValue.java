package developerpanel.paypay.jp.dto.returnvalues;

public class BaseReturnValue implements ServiceReturnValue {
	private Integer currentPage;
	private Integer pageSize;
	private Integer totalPages;
	
	public Integer getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}


}
