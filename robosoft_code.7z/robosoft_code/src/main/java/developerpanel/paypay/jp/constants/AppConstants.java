package developerpanel.paypay.jp.constants;


import developerpanel.paypay.jp.dto.response.ResultInfoDto;

public class AppConstants {

    private static final String DEFAULT_SUCCESS_CODE = "10001";
    private static final String SUCCESS_MESSAGE = "SUCCESS";
    public static final ResultInfoDto API_SUCCESS = new ResultInfoDto(DEFAULT_SUCCESS_CODE, SUCCESS_MESSAGE, "Success" );
    public static final ResultInfoDto TEST_GENERAL_EXCEPTION = new ResultInfoDto("109001", "INTERNAL_SERVER_ERROR", "Failure" );
    public static final ResultInfoDto USER_NOT_FOUND = new ResultInfoDto("10002", "USER_NOT_FOUND", "User is not found" );

}

