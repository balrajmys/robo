package developerpanel.paypay.jp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeveloperpanelApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeveloperpanelApplication.class, args);
    }

}
