package developerpanel.paypay.jp.exception.handler;


import developerpanel.paypay.jp.constants.AppConstants;
import developerpanel.paypay.jp.dto.response.ResultInfoDto;
import developerpanel.paypay.jp.dto.returnvalues.GenericServerResponse;
import developerpanel.paypay.jp.exception.TestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletResponse;

@ControllerAdvice
public class GlobalExceptionHandler {


    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static final String DEFAULT_EXCEPTION_CAUSE_FORMAT = "Exception : {} , Cause : {}";

    @ExceptionHandler(Exception.class)
    public ResponseEntity<GenericServerResponse> generalException(final HttpServletResponse response, Exception e) {

        if (null == e.getMessage()) {
            LOGGER.error(DEFAULT_EXCEPTION_CAUSE_FORMAT, e.getClass(), e.getMessage(), e);
        } else {
            LOGGER.error(DEFAULT_EXCEPTION_CAUSE_FORMAT, e.getClass(), e.getMessage());
        }

        ResultInfoDto info = new ResultInfoDto();
        info.setCode(AppConstants.TEST_GENERAL_EXCEPTION.getCode());
        info.setCodeId(AppConstants.TEST_GENERAL_EXCEPTION.getCodeId());
        //info.setMessage(appendRequestId(response, AppConstants.TEST_GENERAL_EXCEPTION.getMessage()));
        GenericServerResponse serverResponse = new GenericServerResponse(info, null);

        return new ResponseEntity<>(serverResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(TestException.class)
    public ResponseEntity<GenericServerResponse> handleGeneralOPAException(final HttpServletResponse response, TestException e) {

        LOGGER.error(DEFAULT_EXCEPTION_CAUSE_FORMAT, e.getClass(), e.getMessage());

        ResultInfoDto info = new ResultInfoDto();
        info.setCode(e.getResultInfo().getCode());
        info.setCodeId(e.getResultInfo().getCodeId());
        String errmsg = e.getResultInfo().getMessage() != null ? e.getResultInfo().getMessage() : e.getMessage();
        //info.setMessage(appendRequestId(response, errmsg));
        GenericServerResponse serverResponse = new GenericServerResponse();
        serverResponse.setResultInfoDto(info);

        return new ResponseEntity<>(serverResponse, e.getStatus());
    }
}

