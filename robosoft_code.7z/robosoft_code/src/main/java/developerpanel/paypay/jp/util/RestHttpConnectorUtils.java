package developerpanel.paypay.jp.util;

import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.security.InvalidParameterException;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;

public class RestHttpConnectorUtils {
    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(RestHttpConnectorUtils.class);
    private static final String ERROR_BODY_MSG = "ERROR BODY : {} , ERROR STATUS : {}";
    public static final String AUTHORIZATION = "Authorization";
    private static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    private OAuth2RestTemplate oAuth2RestTemplate = null;
    private String oAuthClientId;
    private String oAuthClientSecret;
    private RestTemplate restTemplate = null;
    public RestHttpConnectorUtils(final RestTemplate restTemplate) {
        if(null == restTemplate)
            throw new InvalidParameterException("RestTemplate cannot be null.");
        this.restTemplate = restTemplate;
    }
    public RestHttpConnectorUtils(final OAuth2RestTemplate oAuth2RestTemplate, String oAuthClientId, String oAuthClientSecret) {
        if(null == oAuth2RestTemplate || null == oAuthClientId || null == oAuthClientSecret)
            throw new InvalidParameterException("OAuth2RestTemplate and required fields cannot be null.");
        this.oAuth2RestTemplate = oAuth2RestTemplate;
        this.oAuthClientId = oAuthClientId;
        this.oAuthClientSecret = oAuthClientSecret;
    }
    /**
     * To process get rest end points
     *
     * @param endPoint  base url of the rest request to be processed
     * @param headerMap list of header data to sent in the request header
     * @return response entity object
     */
    public ResponseEntity<String> restGET(String endPoint, Map<String, String> headerMap) {
        LOGGER.info(">> Rest Template GET Request : \n\t BaseUrl: {}", endPoint);
        if (null == endPoint) {
            return null;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        if (headerMap != null && headerMap.containsKey(AUTHORIZATION))
            headers.add(AUTHORIZATION, headerMap.get(AUTHORIZATION));
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(endPoint, HttpMethod.GET, requestEntity, String.class);
            LOGGER.debug("Rest Template GET Response >> : \n\t ResponseBody {} \n\t Response status : {}", response.getBody(), response.getStatusCodeValue());
        } catch (HttpStatusCodeException e) {
            LOGGER.debug(ERROR_BODY_MSG, e.getResponseBodyAsString(), e.getRawStatusCode());
            response = new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
        }
        return response;
    }
    /**
     * To process post rest end points
     *
     * @param endPoint    base url of the rest request to be processed
     * @param contentType content type of the request body
     * @param headerMap   list of header data to sent in the request header
     * @param requestBody parameters to be sent in the request body
     * @return response entity object
     */
    public ResponseEntity<String> restPOST(String endPoint, String contentType, Map<String, String> headerMap,
                                           Object requestBody) {
        LOGGER.info(">> Rest Template POST Request : \n\t BaseUrl: {} \n\t RequestBody : {}",
                endPoint, requestBody);
        if (null == endPoint && null == contentType) {
            return null;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        if (headerMap!=null && headerMap.containsKey(AUTHORIZATION))
            headers.add(AUTHORIZATION, headerMap.get(AUTHORIZATION));
        headers.add(CONTENT_TYPE, contentType);
        HttpEntity<Object> requestEntity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(endPoint, HttpMethod.POST, requestEntity, String.class);
            LOGGER.debug("Rest Template POST Response >> : \n\t ResponseBody {} \n\t Response status : {}", response.getBody(), response.getStatusCodeValue());
        } catch (HttpStatusCodeException e) {
            LOGGER.debug(ERROR_BODY_MSG, e.getResponseBodyAsString(), e.getRawStatusCode());
            response = new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
        }
        return response;
    }
    /**
     * To process put rest end points
     *
     * @param endPoint    base url of the rest request to be processed
     * @param contentType content type of the request body
     * @param headerMap   list of header data to sent in the request header
     * @param requestBody parameters to be sent in the request body
     * @return response entity object
     */
    public ResponseEntity<String> restPUT(String endPoint, String contentType, Map<String, String> headerMap,
                                          Object requestBody) {
        LOGGER.info(">> Rest Template PUT Request : \n\t BaseUrl: {} \n\t RequestBody : {}", endPoint, requestBody);
        if (null == endPoint && null == contentType) {
            return null;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        if (headerMap!=null && headerMap.containsKey(AUTHORIZATION))
            headers.add(AUTHORIZATION, headerMap.get(AUTHORIZATION));
        headers.add(CONTENT_TYPE, contentType);
        HttpEntity<Object> requestEntity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.exchange(endPoint, HttpMethod.PUT, requestEntity, String.class);
            LOGGER.debug("Rest Template PUT Response >> : \n\t ResponseBody {} \n\t Response status : {}", response.getBody(), response.getStatusCodeValue());
        } catch (HttpStatusCodeException e) {
            LOGGER.debug(ERROR_BODY_MSG, e.getResponseBodyAsString(), e.getRawStatusCode());
            response = new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
        }
        return response;
    }
    public String getBasicAuthHeader() {
        String oAuthUserPwd = oAuthClientId + ":" + oAuthClientSecret;
        String header = Base64.getEncoder().encodeToString((oAuthUserPwd).getBytes());
        return "Basic " + header;
    }
    /**
     * Common utlity method to generate oauth token
     *
     * @return
     */
    public String getOAuth2AccessToken() {
        String accessToken = oAuth2RestTemplate.getAccessToken().getValue();
        return "Bearer " + accessToken;
    }
}