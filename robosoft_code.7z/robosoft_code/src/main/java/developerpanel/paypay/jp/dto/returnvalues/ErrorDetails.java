package developerpanel.paypay.jp.dto.returnvalues;

public class ErrorDetails {

}
