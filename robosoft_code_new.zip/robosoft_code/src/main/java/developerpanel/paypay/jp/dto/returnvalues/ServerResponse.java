package developerpanel.paypay.jp.dto.returnvalues;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ServerResponse<R, D> {

  @JsonProperty("resultInfo")
  private R resultInfo;

  @JsonProperty("data")
  @JsonInclude(JsonInclude.Include.ALWAYS)
  private D data;

  public ServerResponse() {}

  public ServerResponse(R resultInfo, D data) {
    this.resultInfo = resultInfo;
    this.data = data;
  }

  public R getResultInfo() {
    return resultInfo;
  }

  public void setResultInfo(R resultInfo) {
    this.resultInfo = resultInfo;
  }

  public D getData() {
    return data;
  }

  public void setData(D data) {
    this.data = data;
  }

  @Override
  public String toString() {
    return "{resultInfo : " + resultInfo + ", data : " + data + "}";
  }
}
