package developerpanel.paypay.jp.exception;

import developerpanel.paypay.jp.constants.AppConstants;
import org.springframework.http.HttpStatus;

public class UserNotFoundException extends TestException {

    private static final long serialVersionUID = 1035443399829077255L;

    public UserNotFoundException(String msg) {
        super(msg);
        this.resultInfo = AppConstants.USER_NOT_FOUND;
        this.status = HttpStatus.NOT_FOUND;
    }
}
