package developerpanel.paypay.jp.dto.returnvalues;

public interface ServiceReturnValue {

}
