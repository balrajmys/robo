package developerpanel.paypay.jp.dto.response.service;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@JsonIgnoreProperties(ignoreUnknown = true)
public class ResultInfo {

    @JsonAlias({"resultCode", "code", "result_code"})
    private String code;

    @JsonAlias({"resultCodeId", "codeId", "result_code_id"})
    private String codeId;

    @JsonAlias({"resultMsg", "message", "result_msg"})
    private String message;

    @JsonAlias({"resultStatus", "status", "result_status"})
    private String status;

    public ResultInfo() {

    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCodeId() {
        return codeId;
    }

    public void setCodeId(String codeId) {
        this.codeId = codeId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "{code : " + code + ", codeId : " + codeId + ", message : " + message + ", status : " + status + "}";
    }

}
