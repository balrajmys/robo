package sample.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;
import sample.model.Test;

@Repository
public interface TestRepository extends JpaRepository<Test, Integer> {

    @Nullable
    Test findByTestId(String testId);

}


