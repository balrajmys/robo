package sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import sample.constants.AppConstants;
import sample.dto.request.TestDto;
import sample.dto.response.ResultInfoDto;
import sample.dto.response.TestResponseDto;
import sample.dto.returnvalues.GenericServerResponse;
import sample.service.TestService;

import javax.validation.Valid;


public class TestController {
    @Autowired
    TestService testService;

    @PostMapping("/v1/test")
    public ResponseEntity<GenericServerResponse> storeTest(@Valid @RequestBody TestDto testDto) {

        TestResponseDto responseDto = testService.storeTestInfo(testDto);
        ResultInfoDto info = AppConstants.API_SUCCESS;
        GenericServerResponse serverResponse = new GenericServerResponse(info, responseDto);

        return new ResponseEntity<>(serverResponse, HttpStatus.OK);
    }

}
