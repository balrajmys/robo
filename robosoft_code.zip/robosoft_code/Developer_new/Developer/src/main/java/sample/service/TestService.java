package sample.service;


import sample.dto.request.TestDto;
import sample.dto.response.TestResponseDto;

public interface TestService {
    TestResponseDto storeTestInfo(TestDto testDto);
}
