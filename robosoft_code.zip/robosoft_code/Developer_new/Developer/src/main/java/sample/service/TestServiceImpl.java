package sample.service;


import sample.dto.request.TestDto;
import sample.dto.response.TestResponseDto;
import sample.exception.UserNotFoundException;

public class TestServiceImpl implements TestService {

    @Override
    public TestResponseDto storeTestInfo(TestDto testDto) {

        if (testDto.getId() == null)
            throw new UserNotFoundException("id null");

        TestResponseDto testResponseDto = new TestResponseDto();
        testResponseDto.setId("");
        testResponseDto.setName("");
        return testResponseDto;
    }
}
