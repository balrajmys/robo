package sample.dto.returnvalues;

public interface ServiceReturnValue {

}
