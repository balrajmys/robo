package sample.exception;


import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;
import sample.constants.AppConstants;
import sample.dto.response.ResultInfoDto;
import sample.dto.response.service.ResultInfo;

public class TestException extends RuntimeException {
    protected ResultInfoDto resultInfo = AppConstants.TEST_GENERAL_EXCEPTION;
    protected HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;

    public TestException() {
        super();
    }

    public TestException(@Nullable String msg) {
        super(msg);
    }

    public TestException(HttpStatus status, @Nullable String msg) {
        super(msg);
        this.status = status;
    }

    public TestException(HttpStatus status, @Nullable String msg, ResultInfo resultInfo) {
        super(msg);
        this.resultInfo = new ResultInfoDto(resultInfo.getCodeId(), resultInfo.getCode(), resultInfo.getMessage());
        this.status = status;
    }

    public ResultInfoDto getResultInfo() {
        return resultInfo;
    }

    public void setResultInfo(ResultInfoDto resultInfo) {
        this.resultInfo = resultInfo;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }
}