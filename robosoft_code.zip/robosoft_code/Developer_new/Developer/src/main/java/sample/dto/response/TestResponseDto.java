package sample.dto.response;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sample.dto.returnvalues.ServiceReturnValue;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class TestResponseDto implements ServiceReturnValue {

    private String id;
    private String name;
}

