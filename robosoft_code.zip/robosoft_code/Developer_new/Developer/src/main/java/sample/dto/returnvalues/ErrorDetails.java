package sample.dto.returnvalues;

public class ErrorDetails {

}
