package developerpanel.paypay.jp.Service;

import developerpanel.paypay.jp.dto.request.UserRequest;
import developerpanel.paypay.jp.model.Users;

public interface UserService {
     void adduser(UserRequest userRequest);
    Users findByEmail(String email);
}
