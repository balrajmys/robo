package developerpanel.paypay.jp.dto.request;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserRequest {
    private String id;
    private String email;
    private String password;

}
