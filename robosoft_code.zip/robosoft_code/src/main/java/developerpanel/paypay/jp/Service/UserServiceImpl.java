package developerpanel.paypay.jp.Service;

import developerpanel.paypay.jp.dto.request.UserRequest;
import developerpanel.paypay.jp.model.Users;
import developerpanel.paypay.jp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepository userRepository;
    @Override
    public void adduser(UserRequest userRequest) {
        if(userRequest.getId() != null)
            throw new EntityNotFoundException("Can't find User for ID");
        Users users=new Users();
        users.setEmail(userRequest.getEmail());
        users.setPassword(userRequest.getPassword());
        userRepository.save(users);
    }

    @Override
    public Users findByEmail(String email) {
        Users userResponse= userRepository.findByEmail(email);
        if (userResponse!= null) {
            throw new EntityNotFoundException("Can't find User for ID "+ email);
            //return userResponse;
        }
        return null;
    }

}
