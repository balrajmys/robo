package developerpanel.paypay.jp.repository;

import developerpanel.paypay.jp.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Users, Integer> {
    @Nullable
    Users findByEmail(String email);
}
